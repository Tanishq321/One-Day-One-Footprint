import SwiftUI
import CoreMotion

// MARK: - Custom Colors and Extensions
extension Color {
    static let ecoGreen = Color(hex: "4CAF50") // Primary accent
    static let softGreen = Color(hex: "E8F5E8") // Light green for gradients
    static let lightGray = Color(hex: "F5F5F5") // Card backgrounds
    
    init(hex: String) {
        let scanner = Scanner(string: hex)
        scanner.scanLocation = 0
        var rgbValue: UInt64 = 0
        scanner.scanHexInt64(&rgbValue)
        let r = (rgbValue & 0xff0000) >> 16
        let g = (rgbValue & 0xff00) >> 8
        let b = rgbValue & 0xff
        self.init(red: Double(r) / 0xff, green: Double(g) / 0xff, blue: Double(b) / 0xff)
    }
}

// MARK: - MVVM ViewModels
@MainActor  
class AppViewModel: ObservableObject {
    @Published var reduceMotion: Bool = false
    @Published var lowPowerMode: Bool = false
    @Published var timeOfDay: TimeOfDay = .day // Computed based on hour
    
    enum TimeOfDay { case day, night }
    
    init() {}
    
    func configureSystemState() {
        reduceMotion = UIAccessibility.isReduceMotionEnabled
        lowPowerMode = ProcessInfo.processInfo.isLowPowerModeEnabled
        updateTimeOfDay()
    }
    
    func updateTimeOfDay() {
        let hour = Calendar.current.component(.hour, from: Date())
        timeOfDay = (hour >= 6 && hour < 18) ? .day : .night
    }
}

class ActionSelectionViewModel: ObservableObject {
    @Published var selectedActions: Set<String> = []
    
    let actions = [
        ("Car Travel", "Using a private car for daily commute"),
        ("Public Transport", "Using bus or metro instead of private vehicle"),
        ("Meat-Based Meal", "Eating a meal with meat or animal products"),
        ("Plant-Based Meal", "Eating a plant-based or vegetarian meal"),
        ("High Electricity Use", "Using air conditioning or heavy appliances")
    ]
    
    var impactLevel: ImpactLevel {
        switch selectedActions.count {
        case 0...2: return .light
        case 3...4: return .moderate
        default: return .heavy
        }
    }
    
    enum ImpactLevel { case light, moderate, heavy }
}

@MainActor
class ReflectionPauseViewModel: ObservableObject {
    @Published var isStill: Bool = false
    @Published var showNext: Bool = false
    private let motionManager = CMMotionManager()
    private var stillnessTimer: Timer?
    
    func startMonitoringStillness() {
        guard motionManager.isAccelerometerAvailable else { return }
        motionManager.accelerometerUpdateInterval = 0.1
        motionManager.startAccelerometerUpdates(to: .main) { [weak self] data, error in
            guard let data = data else { return }
            let acceleration = sqrt(pow(data.acceleration.x, 2) + pow(data.acceleration.y, 2) + pow(data.acceleration.z, 2))
            self?.isStill = acceleration < 0.05 // Threshold for stillness
        }
        
        // Check for stillness after 3 seconds
        stillnessTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { [weak self] _ in
            if self?.isStill == true {
                // User was mindful
            }
        }
        
        // Auto-advance after 5 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self] in
            self?.showNext = true
        }
    }
    
    func stopMonitoring() {
        motionManager.stopAccelerometerUpdates()
        stillnessTimer?.invalidate()
    }
}

// MARK: - Supporting Views
struct ParallaxBackground: View {
    let imageName: String
    @State private var motionManager = CMMotionManager()
    @State private var xOffset: CGFloat = 0
    @State private var yOffset: CGFloat = 0
    
    var body: some View {
        GeometryReader { geometry in
            Image(imageName)
                .resizable()
                .scaledToFill()
                .frame(width: geometry.size.width + 50, height: geometry.size.height + 50)
                .offset(x: xOffset, y: yOffset)
                .onAppear {
                    startMotionUpdates()
                }
                .onDisappear {
                    motionManager.stopDeviceMotionUpdates()
                }
        }
    }
    
    private func startMotionUpdates() {
        guard motionManager.isDeviceMotionAvailable else { return }
        motionManager.deviceMotionUpdateInterval = 1.0 / 60.0
        motionManager.startDeviceMotionUpdates(to: .main) { data, error in
            guard let data = data else { return }
            xOffset = CGFloat(data.attitude.roll) * 20
            yOffset = CGFloat(data.attitude.pitch) * 20
        }
    }
}

struct AnimatedFootprintCard: View {
    let impactLevel: ActionSelectionViewModel.ImpactLevel
    let reduceMotion: Bool
    let lowPowerMode: Bool
    
    var animationSpeed: Double {
        if reduceMotion || lowPowerMode { return 0 }
        switch impactLevel {
        case .light: return 2.0
        case .moderate: return 1.5
        case .heavy: return 1.0
        }
    }
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.white.opacity(0.9))
                .shadow(color: Color.black.opacity(0.1), radius: 8, x: 0, y: 4)
            
            TimelineView(.periodic(from: .now, by: animationSpeed)) { timeline in
                Canvas { context, size in
                    let center = CGPoint(x: size.width / 2, y: size.height / 2)
                    let time = timeline.date.timeIntervalSince1970
                    
                    // Draw animated footprint shape
                    var path = Path()
                    let radius = min(size.width, size.height) / 3
                    let phases = 4
                    for i in 0..<phases {
                        let angle = (2 * .pi * Double(i)) / Double(phases) + time * animationSpeed
                        let x = center.x + radius * cos(angle)
                        let y = center.y + radius * sin(angle)
                        if i == 0 {
                            path.move(to: CGPoint(x: x, y: y))
                        } else {
                            path.addLine(to: CGPoint(x: x, y: y))
                        }
                    }
                    path.closeSubpath()
                    
                    context.fill(path, with: .color(Color.ecoGreen.opacity(0.7)))
                    context.stroke(path, with: .color(Color.ecoGreen), lineWidth: 2)
                }
            }
        }
    }
}

// MARK: - Main App
@main
struct OneDayOneFootprintApp: App {
    @StateObject private var appViewModel: AppViewModel

    init() {
        _appViewModel = StateObject(wrappedValue: AppViewModel())
    }
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                WelcomeScreen()
                    .environmentObject(appViewModel)
                    .onAppear {
                        appViewModel.configureSystemState()
                    }
            }
        }
    }
}

// MARK: - Screen 1: Welcome / Intro Screen
struct WelcomeScreen: View {
    @EnvironmentObject var appViewModel: AppViewModel
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: appViewModel.timeOfDay == .day ? [.softGreen, .white] : [.softGreen.opacity(0.7), Color(hex: "2C2C2C")]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack(spacing: 40) {
                Spacer()
                
                VStack(spacing: 16) {
                    Text("One Day, One Footprint")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.primary)
                    
                    Text("Understand the impact of everyday choices")
                        .font(.title3)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                
                Spacer()
                
                NavigationLink(destination: ActionSelectionScreen().environmentObject(appViewModel)) {
                    Text("Start Experience")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, minHeight: 56)
                        .background(Color.ecoGreen)
                        .clipShape(Capsule())
                        .padding(.horizontal, 32)
                }
                .accessibilityLabel("Start the experience")
                
                Spacer()
                
                Text("Created by Tanishq")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                    .padding(.bottom, 20)
            }
            .padding()
        }
        .navigationBarHidden(true)
    }
}

// MARK: - Screen 2: Action Selection Screen
struct ActionSelectionScreen: View {
    @State private var showFootprint = false
    @EnvironmentObject var appViewModel: AppViewModel
    @StateObject var viewModel = ActionSelectionViewModel()
    
    var body: some View {
        ZStack {
            Color(.systemBackground)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                VStack(spacing: 8) {
                    Text("Your Day, Your Choices")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                    
                    Text("Select the actions that describe your day")
                        .font(.title3)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding(.top, 40)
                
                ScrollView {
                    VStack(spacing: 16) {
                        ForEach(viewModel.actions, id: \.0) { action in
                            ActionCard(title: action.0, description: action.1, isSelected: viewModel.selectedActions.contains(action.0)) {
                                if viewModel.selectedActions.contains(action.0) {
                                    viewModel.selectedActions.remove(action.0)
                                } else {
                                    viewModel.selectedActions.insert(action.0)
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                
                Spacer()
                
                NavigationLink(
                    destination: FootprintInsightScreen(viewModel: viewModel)
                        .environmentObject(appViewModel),
                    isActive: $showFootprint
                ) {
                    Text("See My Footprint")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, minHeight: 56)
                        .background(viewModel.selectedActions.isEmpty ? Color.gray : Color.ecoGreen)
                        .clipShape(Capsule())
                        .padding(.horizontal, 32)
                }
                .disabled(viewModel.selectedActions.isEmpty)
                .accessibilityLabel("View your environmental footprint")
                .padding(.bottom, 20)
            }
        }
        .navigationBarHidden(true)
    }
}

struct ActionCard: View {
    let title: String
    let description: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            Spacer()
            Circle()
                .fill(isSelected ? Color.ecoGreen : Color.clear)
                .frame(width: 24, height: 24)
                .overlay(Circle().stroke(Color.ecoGreen, lineWidth: 2))
        }
        .padding()
        .background(Color.lightGray)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
        .onTapGesture(perform: action)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(title): \(description)")
        .accessibilityAddTraits(.isButton)
    }
}

// MARK: - Screen 3: Footprint Insight Screen
struct FootprintInsightScreen: View {
    @EnvironmentObject var appViewModel: AppViewModel
    let viewModel: ActionSelectionViewModel
    
    var impactTitle: String {
        switch viewModel.impactLevel {
        case .light: return "Light Footprint"
        case .moderate: return "Moderate Footprint"
        case .heavy: return "Heavy Footprint"
        }
    }
    
    var impactDescription: String {
        switch viewModel.impactLevel {
        case .light: return "Your choices today leave a lighter impact on the planet."
        case .moderate: return "Your choices today have a moderate impact on the planet."
        case .heavy: return "Your choices today have a heavier impact on the planet."
        }
    }
    
    var body: some View {
        ZStack {
            ParallaxBackground(imageName: "nature_background")
                .ignoresSafeArea()
                .opacity(0.8)
            
            VStack(spacing: 40) {
                Spacer()
                
                Text(impactTitle)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
                
                AnimatedFootprintCard(impactLevel: viewModel.impactLevel, reduceMotion: appViewModel.reduceMotion, lowPowerMode: appViewModel.lowPowerMode)
                    .frame(height: 200)
                    .padding(.horizontal, 32)
                
                Text(impactDescription)
                    .font(.title3)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
                
                Spacer()
                
                NavigationLink(destination: ReflectionPauseScreen(viewModel: ReflectionPauseViewModel(), selectedActions: viewModel.selectedActions, impactLevel: viewModel.impactLevel).environmentObject(appViewModel)) {
                    Text("Reflect on My Impact")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, minHeight: 56)
                        .background(Color.ecoGreen)
                        .clipShape(Capsule())
                        .padding(.horizontal, 32)
                }
                .accessibilityLabel("Reflect on your impact")
                
                Spacer()
            }
            .padding()
        }
        .navigationBarHidden(true)
    }
}

// MARK: - Screen 4: Reflection Pause Screen
struct ReflectionPauseScreen: View {
    @EnvironmentObject var appViewModel: AppViewModel
    @ObservedObject var viewModel: ReflectionPauseViewModel
    let selectedActions: Set<String>
    let impactLevel: ActionSelectionViewModel.ImpactLevel
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [.softGreen.opacity(0.5), .white]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
                .blur(radius: 2)
            
            VStack(spacing: 20) {
                Spacer()
                
                Text("Take a moment.")
                    .font(.largeTitle)
                    .foregroundColor(.primary)
                
                Text("The planet does not rush.")
                    .font(.title3)
                    .foregroundColor(.secondary)
                
                HStack(spacing: 8) {
                    ForEach(0..<3) { _ in
                        Circle()
                            .fill(Color.ecoGreen.opacity(0.5))
                            .frame(width: 8, height: 8)
                    }
                }
                
                Spacer()
            }
            .padding()
        }
        .onAppear {
            viewModel.startMonitoringStillness()
        }
        .onDisappear {
            viewModel.stopMonitoring()
        }
        .onTapGesture {
            viewModel.showNext = true
        }
        .navigationDestination(isPresented: $viewModel.showNext) {
            ResultScreen(selectedActions: selectedActions, impactLevel: impactLevel, wasMindful: viewModel.isStill)
                .environmentObject(appViewModel)
        }
        .navigationBarHidden(true)
    }
}

// MARK: - Screen 5: Result / Reflection Screen
struct ResultScreen: View {
    @EnvironmentObject var appViewModel: AppViewModel
    let selectedActions: Set<String>
    let impactLevel: ActionSelectionViewModel.ImpactLevel
    let wasMindful: Bool
    
    var reflectionMessage: String {
        "Every choice you make contributes to the planet's story. Reflect on how small changes can create ripples of positive impact."
    }
    
    var body: some View {
        ZStack {
            ParallaxBackground(imageName: "nature_background")
                .ignoresSafeArea()
                .opacity(0.8)
            
            VStack(spacing: 40) {
                Spacer()
                
                Text("Your Impact Today")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
                
                AnimatedFootprintCard(impactLevel: impactLevel, reduceMotion: appViewModel.reduceMotion, lowPowerMode: appViewModel.lowPowerMode)
                    .frame(height: 200)
                    .padding(.horizontal, 32)
                
                Text(reflectionMessage)
                    .font(.body)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                if wasMindful {
                    Text("Thank you for slowing down.")
                        .font(.subheadline)
                        .foregroundColor(.ecoGreen)
                        .padding(.top, 10)
                }
                
                Spacer()
                
                NavigationLink(destination: WelcomeScreen().environmentObject(appViewModel)) {
                    Text("Try Another Day")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, minHeight: 56)
                        .background(Color.ecoGreen)
                        .clipShape(Capsule())
                        .padding(.horizontal, 32)
                }
                .accessibilityLabel("Try another day")
                
                Text("Small choices, repeated daily, shape the future.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                    .padding(.bottom, 20)
                
                Spacer()
            }
            .padding()
        }
        .navigationBarHidden(true)
    }
}
